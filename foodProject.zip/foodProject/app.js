let dataRequest = new XMLHttpRequest()
dataRequest.open('GET','./items.json')
dataRequest.onload = ()=>{
    let data = JSON.parse(dataRequest.response)
    // console.log(data);
    for(let i=0;i<data.length;i++){
        // console.log(data[i]);
        let imgUrl = data[i].image
        let imgTitle = data[i].title
        let prodPrice = data[i].price
        let prodDesc = data[i].description
        let items = document.getElementById('items')
        items.innerHTML += `<div class="item border p-2 m-2 shadow d-flex flex-column justify-content-between rounded" style="width: 22%;">
        <div class="item-img" style="height:200px;">
            <img src=${imgUrl} class="w-100 h-100" style="border-radius:20%" alt="">
        </div>
        <div class="item-desc" style="margin-top:20px">
            <h5>${imgTitle}</h5>    
            <p>${prodDesc}</p>
            <span style="margin-top:20px">Rs.${prodPrice}</span> <br>
            <button class="text-center bg-primary text-light border border-0 p-2 ps-5 pe-5 w-50 rounded-3 " id="addCart${i}" onclick="addCartF(${i})">Add</button>
            <input type="number" id="numCart${i}" value="1" style="visibility: hidden; width: 1px;">
        </div>
    </div>`
      
    }
}
dataRequest.send();


//to add items into cart list
let cartCountArr = []
let addCart = document.getElementById('addCart')
let cartCount = document.getElementById('cartCount')
let addCartF= (id)=>{
    let data = JSON.parse(dataRequest.response)
    let addCart = document.getElementById(`addCart${id}`)
    let cartList = document.getElementById('cartList')
    
        let x = localStorage.getItem(`cartList${id}`)
        console.log(x);
        if(x !=`cartList${id}`){
        localStorage.setItem(`cartList${id}`,`cartList${id}`)
        console.log("not exist");
   
            cartList.innerHTML += `<li  id="innerCart${id}" class="text-light justify-content-between align-items-center" style="display:flex;">
            <img src=${data[id].image} width="100px" alt="">
            <p class="w-25">${data[id].title}</p>
            <p class="w-25">Rs.${data[id].price}</p>
            <p class="w-25">
                <button id="decrement${id}" onclick="decrement(${id})"> - </button>
                <input type="text" style="width: 45px;" id="itemCount${id}" value="1"/>  
                <button id="increment${id}" onclick="increment(${id})"> + </button> 
                <button onclick="removeProduct(${id})">remove</button> 
                <p id="totalPrice${id}">Rs${data[id].price}</p> 
            </p>
            </li>
            
            <div id="total" style="color: #fff;">
            <span>Total Amount :<p id="amountappend"></p></span>
          </div>`
            
            let totalamount = document.getElementById("amountappend")
            console.log(totalamount);
            totalamount.innerText=`RS ${data[id].price}`
//    let itemCount = document.getElementById(`itemCount${id}`)
//     itemCount.value = 1

} else {
    let itemCount = document.getElementById(`itemCount${id}`)
    itemCount.value++; 
    let totalPrice = document.getElementById(`totalPrice${id}`)
    totalPrice.innerText = `Rs.${itemCount.value*data[id].price}`
    console.log("already exist");

    
}

    // addCart.removeEventListener('click',addCartF)
}


function increment(id){
    let data = JSON.parse(dataRequest.response)
    let itemCount = document.getElementById(`itemCount${id}`)
    let totalPrice = document.getElementById(`totalPrice${id}`)
    let increment = document.getElementById("increment")
    console.log(itemCount)
  
    if(itemCount.value >=0 ){
        itemCount.value++;
        totalPrice.innerText = `Rs.${itemCount.value*data[id].price}`
    }
    
}

function decrement(id){
    let data = JSON.parse(dataRequest.response)
    let itemCount = document.getElementById(`itemCount${id}`)
    let totalPrice = document.getElementById(`totalPrice${id}`)
    console.log(itemCount)
    if(itemCount.value>1){
        console.log(itemCount.value)
        itemCount.value--
        totalPrice.innerText = itemCount.value*data[id].price
    }
    else{
        let innerCart = document.getElementById(`innerCart${id}`)
        innerCart.style.display = 'none'
        localStorage.removeItem(`cartList${id}`);
    }
}


function removeProduct(id){
    let innerCart = document.getElementById(`innerCart${id}`)
    console.log(innerCart);
    innerCart.style.display = 'none'
    localStorage.removeItem(`cartList${id}`);
}

