let login= document.getElementById("signin")
let form = document.getElementById("form")

//form registration for new user
let register=document.getElementById("register")
register.addEventListener("click",()=>{
   let registerForm=document.getElementById("registerForm")
   registerForm.style.visibility="visible"
   form.style.visibility="hidden"
   let registerBtn=document.getElementById("registerBtn")
   registerBtn.addEventListener("click",()=>{
      let userName=document.getElementById("userName").value
      let userEmail=document.getElementById("userEmail").value
      let userPwd=document.getElementById("userPwd").value
      let userAdd=document.getElementById("userAdd").value
      if((userEmail!="") && (userName!="") && (userPwd!="")){
         localStorage.setItem("name",userName)
         localStorage.setItem("email",userEmail)
         localStorage.setItem("pwd",userPwd)
         localStorage.setItem("add",userAdd)
         
         registerForm.style.visibility="hidden"
         
         form.style.visibility="visible"
      } else{
         window.alert("please fill all the details")
      }
   })

 })

//to check the login details
      let loginBtn=document.getElementById("loginBtn")
      loginBtn.addEventListener("click",()=>{
      let mailInput=document.getElementById("mailInput").value
      let passwordInput=document.getElementById("passwordInput").value
      if (mailInput !== '' && passwordInput!== ''){
      let mail = localStorage.getItem('email')
      let password = localStorage.getItem('pwd')
          if ((mailInput == mail) && (passwordInput == password)){
               form.style.visibility="hidden"
                window.alert("login success");
               window.open("index.html")
               
          }
          else if(mailInput !== mail){
              window.alert('Enter Valid E-mail ID');
          }
          else if(passwordInput!==password){
              window.alert('Enter Correct Password');
          }
      }
      else{
          alert('please fill out all the fields')
      }
})












